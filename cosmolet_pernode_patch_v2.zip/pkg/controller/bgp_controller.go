
package controller

import (
	"context"
	"log"
	"net"
	"sync"
	"time"

	corev1 "k8s.io/api/core/v1"
	discoveryv1 "k8s.io/api/discovery/v1"
	"k8s.io/client-go/informers/core/v1"
	"k8s.io/client-go/informers/discovery/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/cache"

	"github.com/platformbuilds/cosmolet/pkg/frr"
	"github.com/platformbuilds/cosmolet/pkg/metrics"
)

type Config struct {
	NodeName             string
	LoopInterval         time.Duration
	ServiceInformer      v1.ServiceInformer
	EndpointSliceInformer v1discovery.EndpointSliceInformer
	NodeInformer         v1.NodeInformer
	KubeClient           *kubernetes.Clientset
	// FRR
	ASN                  int
	EnsureStatic         bool
	VTYSHPath            string
}

type controller struct {
	cfg      Config
	frr      frr.Manager
	// desired/actual state key: ip/cidr string
	mu       sync.Mutex
	desired  map[string]bool
	announced map[string]bool
}

func NewBGPController(cfg Config) (*controller, error) {
	mgr := frr.NewVTYSH(frr.Config{ASN: cfg.ASN, EnsureStatic: cfg.EnsureStatic, VTYSHPath: cfg.VTYSHPath})
	c := &controller{
		cfg: cfg,
		frr: mgr,
		desired: map[string]bool{},
		announced: map[string]bool{},
	}
	// Event handlers to poke reconcile sooner
	cfg.ServiceInformer.Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
		UpdateFunc: func(_, _ interface{}){ go c.ReconcileOnce(context.Background()) },
		DeleteFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
	})
	cfg.EndpointSliceInformer.Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
		UpdateFunc: func(_, _ interface{}){ go c.ReconcileOnce(context.Background()) },
		DeleteFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
	})
	cfg.NodeInformer.Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
		AddFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
		UpdateFunc: func(_, _ interface{}){ go c.ReconcileOnce(context.Background()) },
		DeleteFunc: func(obj interface{}){ go c.ReconcileOnce(context.Background()) },
	})
	return c, nil
}

func (c *controller) Run(ctx context.Context) {
	t := time.NewTicker(c.cfg.LoopInterval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			c.ReconcileOnce(ctx)
		}
	}
}

func (c *controller) WithdrawAll(ctx context.Context) {
	c.mu.Lock()
	keys := make([]string, 0, len(c.announced))
	for k := range c.announced { keys = append(keys, k) }
	c.mu.Unlock()

	for _, k := range keys {
		ip, pfxLen := parseCIDRKey(k)
		if err := c.frr.WithdrawVIP(ip, pfxLen); err != nil {
			log.Printf("withdraw %s error: %v", k, err)
		} else {
			metrics.VIPWithdrawn.WithLabelValues("*","*", ipFamily(ip), c.cfg.NodeName).Inc()
		}
	}
}

func (c *controller) ReconcileOnce(ctx context.Context) {
	defer func(){ recover() }()
	c.computeDesired(ctx)
	c.apply(ctx)
}

func (c *controller) computeDesired(ctx context.Context) {
	// Reset desired and recompute from live listers
	desired := map[string]bool{}

	svcs, _ := c.cfg.ServiceInformer.Lister().List(labelsEverything{})
	node, _ := c.cfg.NodeInformer.Lister().Get(c.cfg.NodeName)
	if node == nil { return }
	nodeSched := !node.Spec.Unschedulable
	nodeDraining := false
	for _, cond := range node.Status.Conditions {
		if cond.Type == corev1.NodeReady && cond.Status != corev1.ConditionTrue {
			// still allowed, but you may choose to gate on readiness; we don't hard-block here
		}
		if cond.Type == corev1.NodeNetworkUnavailable && cond.Status == corev1.ConditionTrue {
			// network unavailable: avoid announcing
			nodeDraining = true
		}
	}

	for _, svc := range svcs {
		// Read optional annotation gate
		var annGate *bool
		if v, ok := svc.Annotations["cosmolet.platformbuilds.io/announce"]; ok {
			b := strings.ToLower(v) == "true"
			annGate = &b
		}

		// Gather EndpointSlices for this service
		eps, _ := c.cfg.EndpointSliceInformer.Lister().EndpointSlices(svc.Namespace).List(labelsEverything{})
		esForSvc := []*discoveryv1.EndpointSlice{}
		for _, es := range eps {
			if es.Labels[discoveryv1.LabelServiceName] == svc.Name {
				esForSvc = append(esForSvc, es)
			}
		}

		policy := PolicyAuto
		if ShouldAdvertise(c.cfg.NodeName, svc, esForSvc, policy, nodeSched, nodeDraining, annGate) {
			v4, v6 := ExtractVIPs(svc)
			for _, ip := range v4 { desired[frr.Key(ip, 32)] = true }
			for _, ip := range v6 { desired[frr.Key(ip, 128)] = true }
			metrics.EndpointsReady.WithLabelValues(svc.Name, svc.Namespace, c.cfg.NodeName).Set(float64(localReadyEndpoints(c.cfg.NodeName, esForSvc, svc)))
		} else {
			metrics.EndpointsReady.WithLabelValues(svc.Name, svc.Namespace, c.cfg.NodeName).Set(0)
		}
	}
	c.mu.Lock()
	c.desired = desired
	c.mu.Unlock()
}

func ipFamily(ip net.IP) string {
	if ip.To4() != nil { return "ipv4" }
	return "ipv6"
}

func parseCIDRKey(k string) (net.IP, int) {
	// k is ip/prefix
	parts := strings.Split(k, "/")
	pfx := 32
	if strings.Contains(parts[0], ":") { pfx = 128 }
	if len(parts) == 2 {
		if n, err := strconv.Atoi(parts[1]); err == nil { pfx = n }
	}
	return net.ParseIP(parts[0]), pfx
}

func (c *controller) apply(ctx context.Context) {
	c.mu.Lock()
	desired := make(map[string]bool, len(c.desired))
	for k,v := range c.desired { desired[k]=v }
	announced := make(map[string]bool, len(c.announced))
	for k,v := range c.announced { announced[k]=v }
	c.mu.Unlock()

	// Announce missing desired
	for k := range desired {
		if !announced[k] {
			ip, pfx := parseCIDRKey(k)
			if err := c.frr.AnnounceVIP(ip, pfx); err != nil {
				metrics.ReconcileErrors.Inc()
				log.Printf("announce %s failed: %v", k, err)
				continue
			}
			metrics.VIPAdvertised.WithLabelValues("*","*", ipFamily(ip), c.cfg.NodeName).Inc()
			announced[k] = true
		}
	}

	// Withdraw stale
	for k := range announced {
		if !desired[k] {
			ip, pfx := parseCIDRKey(k)
			if err := c.frr.WithdrawVIP(ip, pfx); err != nil {
				metrics.ReconcileErrors.Inc()
				log.Printf("withdraw %s failed: %v", k, err)
				continue
			}
			metrics.VIPWithdrawn.WithLabelValues("*","*", ipFamily(ip), c.cfg.NodeName).Inc()
			delete(announced, k)
		}
	}

	c.mu.Lock()
	c.announced = announced
	c.mu.Unlock()
}

// labelsEverything is a small helper to List everything; real code should use selectors.
type labelsEverything struct{}
func (labelsEverything) Matches(_ labels.Labels) bool { return true }
func (labelsEverything) Empty() bool { return true }
func (labelsEverything) String() string { return "" }
