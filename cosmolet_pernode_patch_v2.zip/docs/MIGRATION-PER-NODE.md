
# Migration: Leader → Per-Node Announcer

This release removes leader election and makes each DaemonSet pod act independently to announce/withdraw Service VIPs via FRR on its node.

## Steps
1. Upgrade the image and Helm chart from this patch.
2. Ensure each node's FRR peers with the ToR/Core and has ECMP enabled:
   - `bgp bestpath as-path multipath-relax`
   - `maximum-paths 8` (ipv4/ipv6 unicast)
3. If advertising ClusterIP VIPs, enable IPVS kube-proxy with `--ipvs-strict-arp=true`.
4. Verify announcements on ToR/Core with `show ip bgp` / `show bgp ipv6`.
5. Run failure drills: cordon/drain a node and confirm withdraw on that node.

## Notes
- `externalTrafficPolicy: Local` → advertise only from nodes with local **ready** endpoints.
- `externalTrafficPolicy: Cluster` → advertise from all nodes (ECMP).
