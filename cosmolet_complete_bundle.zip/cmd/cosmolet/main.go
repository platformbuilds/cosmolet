
package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"

	cosmoctrl "github.com/platformbuilds/cosmolet/pkg/controller"
)

func getenvInt(name string, def int) int {
	if v := os.Getenv(name); v != "" {
		if n, err := strconv.Atoi(v); err == nil { return n }
	}
	return def
}
func getenvBool(name string, def bool) bool {
	if v := os.Getenv(name); v != "" {
		if v == "1" || v == "true" || v == "TRUE" { return true }
		if v == "0" || v == "false" || v == "FALSE" { return false }
	}
	return def
}
func getenv(name, def string) string {
	if v := os.Getenv(name); v != "" { return v }
	return def
}

func main() {
	var kubeconfig string
	var resyncSeconds int
	var loopIntervalSeconds int

	flag.StringVar(&kubeconfig, "kubeconfig", "", "Path to kubeconfig (in-cluster if empty)")
	flag.IntVar(&resyncSeconds, "resync-seconds", 300, "Shared informer resync period seconds")
	flag.IntVar(&loopIntervalSeconds, "loop-interval-seconds", 30, "Reconcile loop interval seconds")
	flag.Parse()

	nodeName := os.Getenv("NODE_NAME")
	if nodeName == "" {
		log.Fatalf("NODE_NAME env var must be set via Downward API")
	}

	// Build k8s client
	var cfg *rest.Config
	var err error
	if kubeconfig != "" {
		cfg, err = clientcmd.BuildConfigFromFlags("", kubeconfig)
	} else {
		cfg, err = rest.InClusterConfig()
	}
	if err != nil { log.Fatalf("failed building kube config: %v", err) }

	client, err := kubernetes.NewForConfig(cfg)
	if err != nil { log.Fatalf("failed creating kube client: %v", err) }

	// Shared informer factory
	factory := informers.NewSharedInformerFactory(client, time.Duration(resyncSeconds)*time.Second)

	// Informers we need
	svcInf := factory.Core().V1().Services()
	nodeInf := factory.Core().V1().Nodes()
	epsInf := factory.Discovery().V1().EndpointSlices()

	stop := make(chan struct{})
	defer close(stop)
	factory.Start(stop)
	factory.WaitForCacheSync(stop)

	// Metrics HTTP server
	go func() {
		http.Handle("/metrics", promhttp.Handler())
		http.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request){ w.WriteHeader(200); w.Write([]byte("ok")) })
		http.HandleFunc("/readyz", func(w http.ResponseWriter, _ *http.Request){ w.WriteHeader(200); w.Write([]byte("ready")) })
		log.Printf("Metrics listening on :8080")
		_ = http.ListenAndServe(":8080", nil)
	}()

	asn := getenvInt("BGP_ASN", 65001)
	ensureStatic := getenvBool("FRR_ENSURE_STATIC", true)
	vtyshPath := getenv("VTYSH_PATH", "/usr/bin/vtysh")

	// Controller
	ctrl, err := cosmoctrl.NewBGPController(cosmoctrl.Config{
		NodeName:              nodeName,
		LoopInterval:          time.Duration(loopIntervalSeconds) * time.Second,
		ServiceInformer:       svcInf,
		EndpointSliceInformer: epsInf,
		NodeInformer:          nodeInf,
		KubeClient:            client,
		ASN:                   asn,
		EnsureStatic:          ensureStatic,
		VTYSHPath:             vtyshPath,
	})
	if err != nil { log.Fatalf("failed creating controller: %v", err) }

	// Start reconcile loop
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go ctrl.Run(ctx)

	// Handle termination signals: perform best-effort withdraw
	sigc := make(chan os.Signal, 2)
	signal.Notify(sigc, syscall.SIGINT, syscall.SIGTERM)
	<-sigc
	log.Printf("Shutdown signal received, withdrawing VIPs announced by this node...")
	ctrl.WithdrawAll(context.Background())
	log.Printf("Shutdown complete.")
}
