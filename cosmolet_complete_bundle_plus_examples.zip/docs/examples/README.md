
# Examples Index

This folder contains battle-tested example snippets you can adapt.

## Helm values
- `helm/values-single-tor.yaml` — Single ToR eBGP per node.
- `helm/values-dual-tor.yaml` — Dual ToR eBGP per node (ECMP).
- `helm/values-route-reflector.yaml` — iBGP to Route Reflectors.
- `helm/values-dualstack.yaml` — Dual-stack cluster with IPv4+IPv6 VIPs.
- `helm/values-no-static.yaml` — Disable Null0 static origination (VIP bound by IPVS/dummy).

## FRR on nodes (per-node)
- `frr/node-frr-single-tor.conf`
- `frr/node-frr-dual-tor.conf`
- `frr/node-frr-rr.conf` (iBGP to route reflectors)

## FRR on ToR / Route Reflector
- `frr/tor-frr-ebgp.conf`
- `frr/rr-frr-ibgp.conf`

## Services (Kubernetes)
- `k8s/svc-lb-local.yaml` — LoadBalancer + eTP Local (symmetry).
- `k8s/svc-lb-cluster.yaml` — LoadBalancer + eTP Cluster (ECMP everywhere).
- `k8s/svc-dualstack-lb.yaml` — Dual-stack LoadBalancer.
- `k8s/svc-clusterip-advertise.yaml` — (Advanced) Advertising ClusterIP w/ IPVS.

## Kube-proxy IPVS (for ClusterIP advertisements)
- `k8s/kube-proxy-ipvs-configmap.yaml`

## Observability
- `monitoring/cosmolet-service.yaml` — Service to expose metrics.
- `monitoring/servicemonitor.yaml` — Prometheus Operator scrape.
- `monitoring/prometheus-rules.yaml` — Alerts.

## NetworkPolicy
- `networkpolicy/allow-metrics.yaml` — Allow Prometheus -> Cosmolet :8080.
