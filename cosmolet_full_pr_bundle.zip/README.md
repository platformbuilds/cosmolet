
<h1 align="center">Cosmolet</h1>
<p align="center"><em>Per-node BGP announcements (via FRR) for Kubernetes Service VIPs — ECMP-ready, cloud LB feel on bare metal.</em></p>

---

**Docs landing:** 👉 [`/docs/index.md`](docs/index.md)  
**Examples index:** 👉 [`/docs/examples/README.md`](docs/examples/README.md)

© 2025-08-18 Platformbuilds Inc.
