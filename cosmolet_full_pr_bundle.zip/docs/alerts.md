
# Alerts (Prometheus)

Import from [examples/monitoring/prometheus-rules.yaml](examples/monitoring/prometheus-rules.yaml).
