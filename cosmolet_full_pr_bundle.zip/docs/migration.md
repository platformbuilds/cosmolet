
# Migration: Leader → Per‑Node

No leader election remains. Validate with: [svc-lb-local.yaml](examples/k8s/svc-lb-local.yaml) and watch VIP path count on ToR using [tor-frr-ebgp.conf](examples/frr/tor-frr-ebgp.conf) as baseline.
