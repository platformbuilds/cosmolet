# Migrate to Per-Node Announcer Mode

This patch removes leader election and turns Cosmolet into a **per-node announcer**.
Every DaemonSet pod independently advertises/withdraws Service VIPs to FRR on its host.

## Key behavior

- **eTP=Local**: a node advertises a Service IP **only if it has a ready endpoint** for that Service.
- **eTP=Cluster** (or unspecified): **all nodes** advertise the Service IP.
- Works for **ClusterIP** and **LoadBalancer** IPs (can be restricted in code/config as needed).
- Uses **EndpointSlice** to detect node-local ready endpoints.
- Ensures FRR has a matching route by adding a **static Null0** route before issuing `network` statements.

## Helm changes

- DaemonSet now sets `NODE_NAME` from the Downward API.
- RBAC granted for `services`, `endpointslices`, and `nodes` (list/watch/get).
- Still mounts `/var/run/frr` from the host to access FRR via `vtysh`.

## Safety & Ops

- Reconciliation loop runs every `config.loopIntervalSeconds` (default 30s).
- On shutdown, the controller **withdraws** all VIPs it advertised from this node.
- Metrics endpoints stubbed on `:8080` (`/healthz`, `/readyz`).

## Edge cases

- With `eTP=Cluster`, traffic may arrive on any node; ensure kube-proxy/IPVS/NAT handle it.
- For `ClusterIP` advertising, ensure kube-proxy runs in **IPVS** with `--ipvs-strict-arp=true` so the VIP is bound on the node.
- ECMP on ToR/core requires consistent BGP attributes across nodes and `maximum-paths` enabled in FRR/peers.

