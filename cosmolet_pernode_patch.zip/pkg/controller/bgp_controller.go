package controller

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
	"net"
	"sort"

	v1 "k8s.io/api/core/v1"
	discoveryv1 "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"

	"cosmolet/pkg/config"
	"cosmolet/pkg/health"
)

// BGPServiceController runs per-node, independently: each node decides whether to advertise VIPs
type BGPServiceController struct {
	ctx       context.Context
	cancel    context.CancelFunc
	client    kubernetes.Interface
	config    *config.Config
	health    *health.Checker
	nodeName  string

	// in-memory state of currently advertised VIPs on this node
	mu             sync.Mutex
	advertisedVIPs map[string]struct{}
}

func NewBGPServiceController(ctx context.Context, client kubernetes.Interface, cfg *config.Config, hc *health.Checker, nodeName string) *BGPServiceController {
	cctx, cancel := context.WithCancel(ctx)
	return &BGPServiceController{
		ctx: cctx, cancel: cancel,
		client: client,
		config: cfg,
		health: hc,
		nodeName: nodeName,
		advertisedVIPs: map[string]struct{}{},
	}
}

func (c *BGPServiceController) Run() error {
	log.Printf("[cosmolet] starting per-node announcer on node=%s", c.nodeName)

	// Quick FRR readiness probe
	if err := c.checkFRR(); err != nil {
		c.health.CheckFRRStatus(false, fmt.Sprintf("FRR not reachable: %v", err))
		return err
	}
	c.health.CheckFRRStatus(true, "FRR reachable via vtysh")

	defer c.cancel()

	t := time.NewTicker(time.Duration(c.config.GetLoopInterval()) * time.Second)
	defer t.Stop()

	for {
		start := time.Now()
		if err := c.reconcileOnce(); err != nil {
			log.Printf("[cosmolet] reconcile error: %v", err)
		}
		c.health.CheckServiceDiscovery(0, time.Since(start)) // count filled in below if needed

		select {
		case <-c.ctx.Done():
			log.Printf("[cosmolet] context done, withdrawing all VIPs from node=%s", c.nodeName)
			_ = c.withdrawAll()
			return nil
		case <-t.C:
		}
	}
}

func (c *BGPServiceController) reconcileOnce() error {
	// List services from configured namespaces
	nsList := c.config.Services.Namespaces
	if len(nsList) == 0 {
		// Fallback: watch all namespaces
		nsList = []string{""}
	}

	desired := make(map[string]struct{}) // VIP string -> present

	totalSvcs := 0
	for _, ns := range nsList {
		// empty ns means all namespaces
		svcList, err := c.client.CoreV1().Services(ns).List(c.ctx, metav1.ListOptions{})
		if err != nil {
			return fmt.Errorf("list services ns=%s: %w", ns, err)
		}
		totalSvcs += len(svcList.Items)
		for _, svc := range svcList.Items {
			vips := collectVIPs(&svc)
			if len(vips) == 0 {
				continue
			}
			// Determine advertisement policy for this node
			should, err := c.shouldAdvertiseForService(&svc)
			if err != nil {
				log.Printf("[cosmolet] warning: shouldAdvertise error for %s/%s: %v", svc.Namespace, svc.Name, err)
				continue
			}
			if !should {
				continue
			}
			for _, vip := range vips {
				desired[vip] = struct{}{}
			}
		}
	}

	// Update health with counters
	c.health.CheckServiceDiscovery(totalSvcs, 0)

	// Compute diffs
	c.mu.Lock()
	defer c.mu.Unlock()

	// Withdraw VIPs that are no longer desired
	for vip := range c.advertisedVIPs {
		if _, ok := desired[vip]; !ok {
			if err := c.withdrawVIP(vip); err != nil {
				log.Printf("[cosmolet] withdraw VIP %s failed: %v", vip, err)
				continue
			}
			delete(c.advertisedVIPs, vip)
		}
	}
	// Announce new desired VIPs
	// sort for deterministic vtysh order
	vips := make([]string, 0, len(desired))
	for vip := range desired {
		if _, already := c.advertisedVIPs[vip]; already {
			continue
		}
		vips = append(vips, vip)
	}
	sort.Strings(vips)
	for _, vip := range vips {
		if err := c.announceVIP(vip); err != nil {
			log.Printf("[cosmolet] announce VIP %s failed: %v", vip, err)
			continue
		}
		c.advertisedVIPs[vip] = struct{}{}
	}

	return nil
}

func (c *BGPServiceController) withdrawAll() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	for vip := range c.advertisedVIPs {
		_ = c.withdrawVIP(vip)
		delete(c.advertisedVIPs, vip)
	}
	return nil
}

// Decision engine: per-node logic
func (c *BGPServiceController) shouldAdvertiseForService(svc *v1.Service) (bool, error) {
	// Filter by type: enable for LoadBalancer; optionally ClusterIP (config may allow both)
	supported := map[v1.ServiceType]bool{
		v1.ServiceTypeLoadBalancer: true,
		v1.ServiceTypeClusterIP:    true, // can be toggled in config later
	}
	if !supported[svc.Spec.Type] {
		return false, nil
	}
	// No IP -> nothing to do
	if len(collectVIPs(svc)) == 0 {
		return false, nil
	}

	// ExternalTrafficPolicy handling
	policy := strings.ToLower(string(svc.Spec.ExternalTrafficPolicy))
	switch policy {
	case "local":
		// advertise only if this node has a ready endpoint for the service
		localReady, err := c.nodeHasReadyEndpoint(svc)
		if err != nil {
			return false, err
		}
		return localReady, nil
	default:
		// Cluster or empty -> advertise from all nodes
		return true, nil
	}
}

// Uses EndpointSlice to check if the current node has a ready endpoint for the service
func (c *BGPServiceController) nodeHasReadyEndpoint(svc *v1.Service) (bool, error) {
	selector := fmt.Sprintf("kubernetes.io/service-name=%s", svc.Name)
	esList, err := c.client.DiscoveryV1().EndpointSlices(svc.Namespace).List(c.ctx, metav1.ListOptions{
		LabelSelector: selector,
	})
	if err != nil {
		return false, fmt.Errorf("list endpointslices: %w", err)
	}
	for _, es := range esList.Items {
		for _, ep := range es.Endpoints {
			if ep.NodeName == nil || *ep.NodeName != c.nodeName {
				continue
			}
			ready := true
			if ep.Conditions.Ready != nil && !*ep.Conditions.Ready {
				ready = false
			}
			if ep.Conditions.Serving != nil && !*ep.Conditions.Serving {
				ready = false
			}
			if ready {
				return true, nil
			}
		}
	}
	return false, nil
}

// Collect VIPs from Service (ClusterIP + LoadBalancer ingress IPs)
func collectVIPs(svc *v1.Service) []string {
	var out []string
	// ClusterIP (single)
	if svc.Spec.ClusterIP != "" && svc.Spec.ClusterIP != "None" {
		out = append(out, svc.Spec.ClusterIP)
	}
	// LoadBalancer ingress IPs
	for _, ing := range svc.Status.LoadBalancer.Ingress {
		if ing.IP != "" {
			out = append(out, ing.IP)
		}
		// Hostname is not supported here
	}
	// dedupe
	seen := map[string]struct{}{}
	ret := make([]string, 0, len(out))
	for _, ip := range out {
		if net.ParseIP(ip) == nil {
			continue
		}
		if _, ok := seen[ip]; ok {
			continue
		}
		seen[ip] = struct{}{}
		ret = append(ret, ip)
	}
	return ret
}

// --- FRR operations (vtysh) ---

// checkFRR makes sure vtysh is callable
func (c *BGPServiceController) checkFRR() error {
	cmd := exec.Command("vtysh", "-c", "show version")
	_, err := cmd.CombinedOutput()
	return err
}

func (c *BGPServiceController) announceVIP(vip string) error {
	isV6 := strings.Contains(vip, ":")
	// Add static route to Null (so FRR has route to announce)
	var staticCmd string
	if isV6 {
		staticCmd = fmt.Sprintf("ipv6 route %s Null0", vip)
	} else {
		staticCmd = fmt.Sprintf("ip route %s/32 Null0", vip)
		if strings.Contains(vip, "/") { // if already has mask
			staticCmd = fmt.Sprintf("ip route %s Null0", vip)
		}
	}
	if err := runVtyshConfig([]string{staticCmd}); err != nil {
		return fmt.Errorf("add static route: %w", err)
	}

	// Network statement in BGP
	var fam, netStmt string
	if isV6 {
		fam = "address-family ipv6 unicast"
		netStmt = fmt.Sprintf("network %s/128", strings.Split(vip, "/")[0])
	} else {
		fam = "address-family ipv4 unicast"
		ip := vip
		if !strings.Contains(ip, "/") {
			ip = ip + "/32"
		}
		netStmt = fmt.Sprintf("network %s", ip)
	}
	bgpASN := c.config.GetBGPASN()
	cmds := []string{
		fmt.Sprintf("router bgp %d", bgpASN),
		fam,
		netStmt,
		"exit-address-family",
	}
	if err := runVtyshConfig(cmds); err != nil {
		return fmt.Errorf("bgp network add: %w", err)
	}

	log.Printf("[cosmolet] announced VIP %s", vip)
	return nil
}

func (c *BGPServiceController) withdrawVIP(vip string) error {
	isV6 := strings.Contains(vip, ":")
	// Remove network statement
	var fam, netStmt string
	if isV6 {
		fam = "address-family ipv6 unicast"
		netStmt = fmt.Sprintf("no network %s/128", strings.Split(vip, "/")[0])
	} else {
		fam = "address-family ipv4 unicast"
		ip := vip
		if !strings.Contains(ip, "/") {
			ip = ip + "/32"
		}
		netStmt = fmt.Sprintf("no network %s", ip)
	}
	bgpASN := c.config.GetBGPASN()
	cmds := []string{
		fmt.Sprintf("router bgp %d", bgpASN),
		fam,
		netStmt,
		"exit-address-family",
	}
	if err := runVtyshConfig(cmds); err != nil {
		log.Printf("[cosmolet] warn: removing bgp network failed for %s: %v", vip, err)
	}
	// Remove static route
	var staticCmd string
	if isV6 {
		staticCmd = fmt.Sprintf("no ipv6 route %s Null0", vip)
	} else {
		staticCmd = fmt.Sprintf("no ip route %s/32 Null0", vip)
		if strings.Contains(vip, "/") {
			staticCmd = fmt.Sprintf("no ip route %s Null0", vip)
		}
	}
	if err := runVtyshConfig([]string{staticCmd}); err != nil {
		log.Printf("[cosmolet] warn: removing static route failed for %s: %v", vip, err)
	}
	log.Printf("[cosmolet] withdrew VIP %s", vip)
	return nil
}

// runVtyshConfig runs a sequence of configuration commands under "configure terminal"
func runVtyshConfig(cmds []string) error {
	args := []string{"-c", "configure terminal"}
	for _, c := range cmds {
		args = append(args, "-c", c)
	}
	// Save is optional; we keep it in running-config only to avoid persistent drift
	cmd := exec.Command("vtysh", args...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("vtysh error: %v: %s", err, string(out))
	}
	return nil
}
