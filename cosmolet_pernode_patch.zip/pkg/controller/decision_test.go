package controller

import (
	"testing"

	v1 "k8s.io/api/core/v1"
)

func TestCollectVIPs(t *testing.T) {
	svc := &v1.Service{}
	svc.Spec.ClusterIP = "10.0.0.100"
	svc.Status.LoadBalancer.Ingress = []v1.LoadBalancerIngress{
		{IP: "10.0.0.200"},
		{IP: "fd00::200"},
	}
	vips := collectVIPs(svc)
	want := map[string]bool{"10.0.0.100": true, "10.0.0.200": true, "fd00::200": true}
	if len(vips) != len(want) {
		t.Fatalf("unexpected count: %v", vips)
	}
	for _, ip := range vips {
		if !want[ip] {
			t.Fatalf("unexpected ip: %s", ip)
		}
	}
}

func TestShouldAdvertiseUnsupportedType(t *testing.T) {
	ctrl := &BGPServiceController{nodeName: "node-a"}
	svc := &v1.Service{}
	svc.Spec.Type = v1.ServiceTypeExternalName
	ok, err := ctrl.shouldAdvertiseForService(svc)
	if err != nil {
		t.Fatalf("err: %v", err)
	}
	if ok {
		t.Fatalf("expected false for ExternalName")
	}
}
