package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"cosmolet/pkg/config"
	"cosmolet/pkg/controller"
	"cosmolet/pkg/health"

	"k8s.io/client-go/kubernetes"
)

var (
	Version   = "dev"
	GitCommit = "unknown"
)

func main() {
	var cfgPath string
	flag.StringVar(&cfgPath, "config", "/etc/cosmolet/config.yaml", "Path to cosmolet config file")
	flag.Parse()

	cfg, err := config.LoadConfig(cfgPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	nodeName := os.Getenv("NODE_NAME")
	if nodeName == "" {
		log.Fatalf("NODE_NAME env must be set (use Downward API to pass spec.nodeName)")
	}

	restCfg, err := controller.GetKubeConfig()
	if err != nil {
		log.Fatalf("kubeconfig: %v", err)
	}
	client := kubernetes.NewForConfigOrDie(restCfg)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	hc := health.NewChecker()
	hc.SetLive(true)
	hc.SetReady(true)

	http.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	http.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	go func() {
		addr := ":8080"
		log.Printf("starting HTTP on %s", addr)
		_ = http.ListenAndServe(addr, nil)
	}()

	ctrl := controller.NewBGPServiceController(ctx, client, cfg, hc, nodeName)

	// signals
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigs
		cancel()
	}()

	if err := ctrl.Run(); err != nil {
		log.Fatalf("controller exited with error: %v", err)
	}
}
