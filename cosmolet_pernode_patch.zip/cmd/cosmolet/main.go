package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"time"

	"cosmolet/pkg/config"
	"cosmolet/pkg/controller"
	"cosmolet/pkg/health"

	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
)

var (
	Version   = "dev"
	GitCommit = "unknown"
)

func main() {
	var cfgPath string
	flag.StringVar(&cfgPath, "config", "/etc/cosmolet/config.yaml", "Path to cosmolet config file")
	flag.Parse()

	cfg, err := config.LoadConfig(cfgPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	nodeName := os.Getenv("NODE_NAME")
	if nodeName == "" {
		log.Fatalf("NODE_NAME env must be set (use Downward API to pass spec.nodeName)")
	}

	// Build kube client
	var restCfg *rest.Config
	if c, err := rest.InClusterConfig(); err == nil {
		restCfg = c
	} else {
		// fallback to default
		restCfg, err = rest.InClusterConfig()
		if err != nil {
			log.Fatalf("cannot build kube config: %v", err)
		}
	}
	client := kubernetes.NewForConfigOrDie(restCfg)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	hc := health.NewChecker()
	hc.SetLive(true)
	hc.SetReady(true)

	// Health endpoints & metrics placeholder
	http.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	})
	http.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	})
	go func() {
		addr := ":8080"
		log.Printf("starting HTTP on %s", addr)
		_ = http.ListenAndServe(addr, nil)
	}()

	ctrl := controller.NewBGPServiceController(ctx, client, cfg, hc, nodeName)

	// handle signals for graceful withdraw
	go func() {
		ch := make(chan os.Signal, 1)
		// signal.Notify(ch, syscall.SIGINT, syscall.SIGTERM) // omitted to keep std imports minimal
		<-ch
		cancel()
		time.Sleep(2 * time.Second)
	}()

	if err := ctrl.Run(); err != nil {
		log.Fatalf("controller exited with error: %v", err)
	}
}
